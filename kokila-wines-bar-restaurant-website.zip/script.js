const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');

toggle.addEventListener('click', () => nav.classList.toggle('open'));

document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', () => nav.classList.remove('open'));
});

document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('bookingForm');
const message = document.getElementById('formMessage');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const date = document.getElementById('date').value;
  const guests = document.getElementById('guests').value;

  if (!name || !date || !guests) {
    message.textContent = 'Please fill in all booking details.';
    return;
  }

  message.textContent = `Thank you, ${name}! Your booking request for ${guests} on ${date} has been received.`;
  form.reset();
});
